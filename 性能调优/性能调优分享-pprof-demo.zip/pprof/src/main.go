package main

import (
	"bytes"
	"fmt"
	"net/http"
	"net/http/pprof"
	"runtime"
	"strconv"
	"strings"
)

var (
	total   = 1000
	arr     = make([]int, 0, total)
	intChan = make(chan int)
)

func init() {
	for i := 0; i < total; i++ {
		arr = append(arr, i)
	}
}

func main() {
	runtime.SetBlockProfileRate(1)
	m := http.NewServeMux()
	// 入口
	m.HandleFunc("/str", myHandler)
	// pprof
	m.HandleFunc("/debug/pprof/", pprof.Index)
	m.HandleFunc("/debug/pprof/cmdline", pprof.Cmdline)
	m.HandleFunc("/debug/pprof/profile", pprof.Profile)
	m.HandleFunc("/debug/pprof/symbol", pprof.Symbol)
	m.HandleFunc("/debug/pprof/trace", pprof.Trace)
	http.ListenAndServe("127.0.0.1:8000", m)

}

// handler函数
func myHandler(w http.ResponseWriter, r *http.Request) {
	reqType := r.URL.Query().Get("type")
	switch reqType {

	case "block":
		go blockDemo()
	default:
		strJoin()
		buffer()
		add()
		fmtAdd()
		fmt.Println("default")
	}
	w.Write([]byte("OK"))
}

func strJoin() {
	var arrStr = make([]string, 0, total)
	for _, v := range arr {
		arrStr = append(arrStr, strconv.Itoa(v))
	}
	strings.Join(arrStr, "")
}
func buffer() {
	byteSlice := make([]byte, total)
	s := bytes.NewBuffer(byteSlice)
	for i := 0; i < total; i++ {
		s.WriteString(strconv.Itoa(i))
	}
	s.String()
}

func add() {
	s := ""
	for i := 0; i < total; i++ {
		s += strconv.Itoa(i)
	}
}

func fmtAdd() {
	s := ""
	for i := 0; i < total; i++ {
		s = fmt.Sprintf("%s%d", s, i)
	}
}

func blockDemo() {
	intChan <- 1
}
